package AllApiDtoClasses;

public final class ApiWatcherCreateDTO {
    public long deptId;
    public long courseId;
}
